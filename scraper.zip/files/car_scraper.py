"""
Kijiji car listing watcher - Winnipeg, 20km radius, $2,500-$5,000, safetied.

Pipeline, step by step:
  1. Reads one or more Kijiji "Cars & Trucks" search URLs from config.py
  2. Opens each one with Playwright and reads title/link/price/snippet off
     the search-results page - same as before.
  3. Drops anything that looks SOLD, and anything outside MIN_PRICE/
     MAX_PRICE. This is a cheap first pass over every listing on the page.
  4. For everything that survives step 3 (should be a small subset), opens
     that listing's OWN page. This is new: the search snippet is too short
     to reliably tell if a car is safetied, so safety wording is judged
     from the full description on the ad's own page, not the preview text.
  5. On that same page, tries to read the listing's real coordinates (if
     the page exposes them) and computes actual distance from downtown
     Winnipeg, with a hard 20km cutoff. Falls back to matching place names
     in the visible text if no coordinates are found.
  6. Classifies safety as SAFETIED / NOT_SAFETIED / UNKNOWN based on the
     full description text.
  7. Remembers what it's already told you about in seen_listings.json.
  8. Emails you about new SAFETIED or UNKNOWN (if enabled) listings.
     NOT_SAFETIED listings are logged to the console but never emailed.

How to run it:
    python car_scraper.py            checks once, then exits
    python car_scraper.py --loop     checks forever, every CHECK_INTERVAL_MINUTES

IMPORTANT CAVEAT on coordinates: extract_coordinates() below guesses at a
few common patterns Kijiji-style listing pages use to embed a map pin's
lat/lng in the page source. This wasn't verified against a live page, so if
it's not finding coordinates on real listings, run:
    python debug_scraper.py --save-html
and open the saved debug_listing.html to see what the real page actually
contains, then adjust the patterns in COORD_PATTERNS to match. Location
filtering still works without this - it just falls back to the place-name
allow/deny lists in config.py, which are less precise.
"""

import json
import math
import re
import smtplib
import sys
import time
from email.mime.text import MIMEText
from pathlib import Path

from playwright.sync_api import sync_playwright

import config

SEEN_FILE = Path(__file__).parent / "seen_listings.json"


def _phrase_pattern(phrases):
    """Compile a case-insensitive, word-boundary alternation of phrases."""
    escaped = [re.escape(p) for p in phrases]
    return re.compile(r"\b(?:" + "|".join(escaped) + r")\b", re.IGNORECASE)


# ---------------------------------------------------------------------------
# Safety-status classification
# ---------------------------------------------------------------------------

# Unambiguous on their own - if one of these appears anywhere, it's a real
# signal even inside a clause that also trips a "false positive trap" below
# (e.g. "new safety features, safetied last week" should still count).
STRONG_MARKER_PATTERN = _phrase_pattern([
    "safetied", "safetyed", "saftied", "saftyed", "safety'd", "safetied out",
    "safety certificate", "safety cert", "mvi certified",
    "manitoba safety certified", "certificat de securite",
    "certificat de sécurité",
])

# Everything that should count as a positive safety signal.
POSITIVE_PATTERN = _phrase_pattern([
    # core word forms / misspellings
    "safetied", "safetyed", "saftied", "saftyed", "safety'd", "safetied out",
    # passed / approved framing
    "safety passed", "passed safety", "passed the safety", "passed mb safety",
    "safety approved", "approved safety", "passed inspection",
    # certificate / cert framing
    "safety certificate", "safety cert", "has a safety certificate",
    "comes with safety", "includes safety", "safety included",
    "cert included", "safety cert included",
    # freshness framing
    "new safety", "fresh safety", "current safety", "valid safety",
    "up to date safety", "up-to-date safety", "recent safety",
    "just safetied", "freshly safetied",
    # Manitoba-specific
    "manitoba safety", "mb safety", "safety certified in manitoba",
    # date-bound
    "safety until", "safety till", "safety good until", "safety valid until",
    # ready-to-drive framing
    "comes safetied", "sold safetied", "safetied and ready", "drive away safetied",
    # French (St. Boniface listings occasionally)
    "securite valide", "sécurité valide", "securite incluse", "sécurité incluse",
    "securite fraiche", "sécurité fraîche",
])

# Promises about the future, not a current status - don't count as positive
# unless a STRONG_MARKER also appears somewhere in the same clause.
TENTATIVE_POSITIVE_PATTERN = _phrase_pattern([
    "will be safetied", "can safety it", "can be safetied",
    "safety before pickup", "safety at extra cost", "will safety it",
])

NEGATIVE_PATTERN = _phrase_pattern([
    # direct negation
    "not safetied", "not saftied", "no safety", "without safety",
    "missing safety", "doesn't come with safety", "does not include safety",
    "doesn't include safety",
    # expired / failed
    "safety expired", "expired safety", "lapsed safety", "failed safety",
    "failed mb safety inspection", "didn't pass safety", "did not pass safety",
    "will not pass safety",
    # as-is family
    "as is", "as-is", "as is where is", "sold as is", "selling as is",
    "private sale as is", "no warranty as is",
    # buyer-responsibility framing
    "buyer responsible for safety", "needs safety to drive",
    "requires safety", "must be safetied by buyer", "needs a safety",
    # parts / mechanic-special framing
    "no mvi", "parts only", "mechanic special", "project car",
    "not driveable", "not drivable",
    # French
    "tel quel", "vendu tel quel", "sans securite", "sans sécurité",
])

# Clauses matching these should NOT count toward either side unless a
# STRONG_MARKER is also present - "new safety features" contains "new
# safety" but is talking about airbags, not an MB inspection.
TRAP_PATTERN = _phrase_pattern([
    "safety feature", "safety features", "safety rating", "safety ratings",
    "safety recall", "child safety lock", "child safety locks",
    "safety belt", "safety belts", "safety glass", "drive safely",
    "drive it home safely", "safety inspection recommended",
    "arrange your own safety", "get your own safety",
    "please get your own safety",
])

# "as is" followed by one of these is describing normal wear, not a
# no-safety private sale - e.g. "some surface rust, as is normal for the age".
AS_IS_EXCEPTION_PATTERN = _phrase_pattern([
    "as is normal", "as is typical", "as is expected", "as is common",
    "as is usual",
])


def split_clauses(text: str) -> list[str]:
    """Split on sentence/clause boundaries so a negative word in one clause
    can't combine with a positive claim in a different one, and vice versa."""
    return re.split(r"[.,;:\n\r]+|\s[-\u2013\u2014]\s|\u2022", text)


def classify_safety(text: str) -> str:
    """Returns 'SAFETIED', 'NOT_SAFETIED', or 'UNKNOWN'."""
    if not text:
        return "UNKNOWN"

    found_positive = False
    found_negative = False

    for clause in split_clauses(text):
        clause = clause.strip()
        if not clause:
            continue

        has_strong_marker = bool(STRONG_MARKER_PATTERN.search(clause))

        if TRAP_PATTERN.search(clause) and not has_strong_marker:
            continue  # false-positive trap, e.g. "safety features"

        negative_clause = clause
        if AS_IS_EXCEPTION_PATTERN.search(clause):
            # "as is normal for the age" isn't a no-safety claim - strip the
            # matched phrase before running the negative check on this clause.
            negative_clause = AS_IS_EXCEPTION_PATTERN.sub("", clause)

        if TENTATIVE_POSITIVE_PATTERN.search(clause) and not has_strong_marker:
            pass  # future promise, not current status
        elif POSITIVE_PATTERN.search(clause):
            found_positive = True

        if NEGATIVE_PATTERN.search(negative_clause):
            found_negative = True

    if found_positive and found_negative:
        return "UNKNOWN"  # contradictory wording - flag for manual review
    if found_positive:
        return "SAFETIED"
    if found_negative:
        return "NOT_SAFETIED"
    return "UNKNOWN"


# ---------------------------------------------------------------------------
# Sold-badge detection
# ---------------------------------------------------------------------------

SOLD_PATTERN = re.compile(r"^\s*sold\b", re.IGNORECASE)


def looks_sold(title: str, card_text: str) -> bool:
    return bool(SOLD_PATTERN.search(title or "") or SOLD_PATTERN.search(card_text or ""))


# ---------------------------------------------------------------------------
# Location: real distance when possible, place-name fallback otherwise
# ---------------------------------------------------------------------------

# Best-effort patterns for lat/lng embedded in a listing page's source (for
# its own map widget). See the module docstring's caveat about verifying
# these against a real page with debug_scraper.py --save-html.
COORD_PATTERNS = [
    re.compile(r'"latitude"\s*:\s*(-?\d{1,3}\.\d+)\s*,\s*"longitude"\s*:\s*(-?\d{1,3}\.\d+)'),
    re.compile(r'"lat"\s*:\s*(-?\d{1,3}\.\d+)\s*,\s*"lng"\s*:\s*(-?\d{1,3}\.\d+)'),
    re.compile(r'"lat"\s*:\s*(-?\d{1,3}\.\d+)\s*,\s*"lon"\s*:\s*(-?\d{1,3}\.\d+)'),
]


def extract_coordinates(html: str):
    for pattern in COORD_PATTERNS:
        match = pattern.search(html or "")
        if match:
            try:
                return float(match.group(1)), float(match.group(2))
            except ValueError:
                continue
    return None


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    radius = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
    return 2 * radius * math.asin(math.sqrt(a))


def resolve_location(detail: dict, fallback_text: str):
    """Returns (status, distance_km_or_None, source) where status is
    'IN_RANGE', 'OUT_OF_RANGE', or 'UNKNOWN'."""
    coords = detail.get("coords")
    if coords:
        distance = haversine_km(
            config.WINNIPEG_CENTER_LAT, config.WINNIPEG_CENTER_LNG, coords[0], coords[1]
        )
        status = "IN_RANGE" if distance <= config.RADIUS_KM else "OUT_OF_RANGE"
        return status, distance, "coordinates"

    combined_text = ((detail.get("text") or "") + " " + (fallback_text or "")).lower()

    for place in config.FAR_PLACE_DENYLIST:
        if place in combined_text:
            return "OUT_OF_RANGE", None, place

    for place in config.NEARBY_PLACE_ALLOWLIST:
        if place in combined_text:
            return "IN_RANGE", None, place

    return "UNKNOWN", None, None


# ---------------------------------------------------------------------------
# Scraping
# ---------------------------------------------------------------------------

# Runs inside the browser page: finds each listing's title link (the one
# with a heading in it, so it skips the plain image links), then walks up
# a few parent elements looking for a "$1,234"-style price nearby, and
# keeps that same element's text as the visible "snippet" for keyword
# checks (safetied, etc.).
EXTRACT_LISTINGS_JS = """
() => {
    function findHref(startNode) {
        let node = startNode;
        for (let i = 0; i < 8 && node; i++) {
            if (node.tagName === 'A' && node.href && node.href.includes('/v-cars-trucks/')) {
                return node.href;
            }
            const nested = node.querySelector ? node.querySelector('a[href*="/v-cars-trucks/"]') : null;
            if (nested) return nested.href;
            node = node.parentElement;
        }
        return null;
    }

    // Only accept a price if it sits immediately before this listing's own
    // title in the text - not just "somewhere in a shared ancestor", which
    // is what was causing one listing's price to leak onto another.
    function findNearbyPrice(startNode, title) {
        let node = startNode;
        for (let i = 0; i < 8 && node; i++) {
            const text = node.textContent;
            const idx = text.indexOf(title);
            if (idx !== -1) {
                const before = text.slice(Math.max(0, idx - 60), idx);
                const match = before.match(/\\$\\d{1,3}(?:,\\d{3})*/);
                if (match) return match[0];
            }
            node = node.parentElement;
        }
        return null;
    }

    const seen = new Set();
    const results = [];
    const headings = document.querySelectorAll('h2, h3, h4');
    for (const heading of headings) {
        const title = heading.textContent.trim();
        if (!title || /^results\\b/i.test(title)) continue;

        const href = findHref(heading);
        if (!href || seen.has(href)) continue;
        seen.add(href);

        const price = findNearbyPrice(heading, title);

        let cardText = title;
        let node = heading;
        for (let i = 0; i < 4 && node; i++) {
            cardText = node.textContent;
            node = node.parentElement;
        }

        results.push({
            title: title,
            link: href,
            price: price || "price not listed",
            cardText: cardText,
        });
    }
    return results;
}
"""


def fetch_listings(search_url: str, page) -> list[dict]:
    page.goto(search_url, wait_until="domcontentloaded", timeout=30000)
    page.wait_for_selector('a[href*="/v-cars-trucks/"]', timeout=15000, state="attached")

    # The links can be attached before the page has finished rendering
    # titles into them (React hydration), so retry for a few seconds
    # instead of grabbing once and giving up.
    listings = []
    for _ in range(6):
        listings = page.evaluate(EXTRACT_LISTINGS_JS)
        if listings:
            break
        page.wait_for_timeout(1500)
    return listings


def fetch_listing_detail(url: str, page) -> dict:
    """Opens a single listing's own page and returns its full text (for
    safety-wording checks) plus any coordinates found (for location)."""
    page.goto(url, wait_until="domcontentloaded", timeout=30000)
    page.wait_for_timeout(1200)
    html = page.content()
    try:
        body_text = page.inner_text("body")
    except Exception:
        body_text = ""
    return {"html": html, "text": body_text, "coords": extract_coordinates(html)}


def parse_price(price_str: str):
    digits = re.sub(r"[^\d]", "", price_str or "")
    return int(digits) if digits else None


def load_seen_ids() -> set:
    if SEEN_FILE.exists():
        return set(json.loads(SEEN_FILE.read_text(encoding="utf-8")))
    return set()


def save_seen_ids(seen_ids: set) -> None:
    SEEN_FILE.write_text(json.dumps(sorted(seen_ids)), encoding="utf-8")


def send_email(subject: str, body: str) -> None:
    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = config.GMAIL_ADDRESS
    msg["To"] = ", ".join(config.NOTIFY_EMAILS)

    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()
        server.login(config.GMAIL_ADDRESS, config.GMAIL_APP_PASSWORD)
        server.sendmail(config.GMAIL_ADDRESS, config.NOTIFY_EMAILS, msg.as_string())


def format_listing_line(item: dict) -> str:
    distance = item.get("distance_km")
    distance_note = f", ~{distance:.1f} km away" if distance is not None else ""
    return f"[{item['safety_status']}] {item['title']} - {item['price']}{distance_note}\n{item['link']}"


def check_once() -> None:
    is_first_run = not SEEN_FILE.exists()
    seen_ids = load_seen_ids()
    new_listings = []
    all_matching_this_run = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()

        for search_url in config.KIJIJI_SEARCH_URLS:
            try:
                listings = fetch_listings(search_url, page)
            except Exception as exc:
                print(f"[warning] couldn't check {search_url}: {exc}")
                continue

            for item in listings:
                if looks_sold(item.get("title", ""), item.get("cardText", "")):
                    continue

                price = parse_price(item.get("price", ""))
                if price is None or not (config.MIN_PRICE <= price <= config.MAX_PRICE):
                    continue

                # Only price-passing, not-sold listings get a detail-page
                # fetch - this is the expensive step, so it's kept small.
                try:
                    detail = fetch_listing_detail(item["link"], page)
                except Exception as exc:
                    print(f"[warning] couldn't open listing {item['link']}: {exc}")
                    continue
                time.sleep(config.DETAIL_FETCH_DELAY_SECONDS)

                loc_status, distance_km, _loc_source = resolve_location(detail, item.get("cardText", ""))
                if loc_status == "OUT_OF_RANGE":
                    continue
                if loc_status == "UNKNOWN" and config.UNKNOWN_LOCATION_POLICY == "exclude":
                    continue

                safety_status = classify_safety(detail.get("text", ""))
                if safety_status == "UNKNOWN" and not config.INCLUDE_UNKNOWN_SAFETY:
                    continue

                tier = {"SAFETIED": 1, "UNKNOWN": 2, "NOT_SAFETIED": 3}[safety_status]

                record = dict(item)
                record["safety_status"] = safety_status
                record["location_status"] = loc_status
                record["distance_km"] = distance_km
                record["tier"] = tier
                all_matching_this_run.append(record)

                if record["link"] not in seen_ids:
                    seen_ids.add(record["link"])
                    if not is_first_run:
                        new_listings.append(record)

        browser.close()

    if is_first_run:
        print(f"First run: found {len(all_matching_this_run)} listing(s) matching your criteria right now:")
        for item in sorted(all_matching_this_run, key=lambda r: r["tier"]):
            print(f"  [tier {item['tier']}, {item['safety_status']}] {item['title']} ({item['price']}) {item['link']}")
        print("These are recorded as the starting point - you'll get an email next time a genuinely NEW tier 1/2 listing shows up.")
    else:
        emailable = sorted([r for r in new_listings if r["tier"] in (1, 2)], key=lambda r: r["tier"])
        logged_only = [r for r in new_listings if r["tier"] == 3]

        if emailable:
            print(f"Found {len(emailable)} new listing(s) worth emailing. Sending now...")
            body = "\n\n".join(format_listing_line(item) for item in emailable)
            send_email(
                subject=f"{len(emailable)} new Kijiji car listing(s) near Winnipeg",
                body=body,
            )
        if logged_only:
            print(f"{len(logged_only)} new listing(s) found but NOT safetied - logged only, not emailed:")
            for item in logged_only:
                print(f"  - {item['title']} ({item['price']}) {item['link']}")
        if not emailable and not logged_only:
            print("No new matching listings this check.")

    save_seen_ids(seen_ids)


def main() -> None:
    if "--loop" in sys.argv:
        print(f"Watching every {config.CHECK_INTERVAL_MINUTES} minute(s). Press Ctrl+C to stop.")
        while True:
            check_once()
            time.sleep(config.CHECK_INTERVAL_MINUTES * 60)
    else:
        check_once()


if __name__ == "__main__":
    main()
