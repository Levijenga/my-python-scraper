"""
Personal settings for the car scraper.

Edit the values below. You should not need to touch car_scraper.py at all,
except to adjust the coordinate-extraction patterns if extract_coordinates()
isn't finding lat/lng on real listing pages - see the note in car_scraper.py
and the --save-html option in debug_scraper.py.
"""

# ---- What to search for ----
# Paste one or more Kijiji search-result URLs here. To get one with a real
# 20km radius baked in: go to kijiji.ca, search "Cars & Trucks", set your
# location to a central Winnipeg address with the 20km distance option in
# Kijiji's own "Radial Search" location picker, then copy the URL straight
# out of your browser's address bar. Don't hand-build the radius part of
# the URL - use whatever Kijiji's own UI produces.
KIJIJI_SEARCH_URLS = [
    "https://www.kijiji.ca/b-cars-trucks/winnipeg/cars/k0c174l1700192r20.0",
]

# Only notify about listings priced in this range (in dollars), inclusive.
MIN_PRICE = 2500
MAX_PRICE = 5000

# ---- Location: hard 20 km limit from downtown Winnipeg ----
# Roughly Portage & Main. Used for real distance math when a listing's page
# exposes coordinates (see extract_coordinates() in car_scraper.py).
WINNIPEG_CENTER_LAT = 49.8951
WINNIPEG_CENTER_LNG = -97.1384
RADIUS_KM = 20

# Fallback text-matching lists, used ONLY when a listing's page doesn't
# expose real coordinates. Matched as lowercase substrings against the ad's
# visible text.
NEARBY_PLACE_ALLOWLIST = [
    "winnipeg", "st. boniface", "st boniface", "st. vital", "st vital",
    "transcona", "east kildonan", "north kildonan", "west kildonan",
    "old kildonan", "st. james", "st james", "assiniboia", "charleswood",
    "fort garry", "river heights", "tuxedo", "wolseley", "elmwood",
    "point douglas", "southdale", "island lakes", "waverley west",
    "sage creek", "the maples", "garden city", "east st. paul",
    "east st paul", "west st. paul", "west st paul", "headingley",
    "oak bluff",
]

# Towns that show up in wider Manitoba results and get mistaken for "close."
FAR_PLACE_DENYLIST = [
    "selkirk", "stonewall", "niverville", "beausejour", "landmark",
    "steinbach", "portage la prairie", "gimli", "winkler", "morden",
]

# What to do when a listing's location can't be confidently placed either
# way (no coordinates found on its page, and the visible text doesn't match
# either list above). "exclude" drops it silently - the safer default,
# since this is meant to be a hard limit. "flag" keeps it in the results
# with location_status == "UNKNOWN" instead of dropping it.
UNKNOWN_LOCATION_POLICY = "exclude"  # "exclude" or "flag"

# ---- Safety status ----
# Every listing gets classified as SAFETIED / NOT_SAFETIED / UNKNOWN.
# NOT_SAFETIED listings are always logged to the console, never emailed.
# This toggles whether UNKNOWN ones get emailed too (tier 2) or just logged
# alongside NOT_SAFETIED (tier 3-style, contact-and-ask-yourself territory).
INCLUDE_UNKNOWN_SAFETY = True

# ---- Checking behavior ----
CHECK_INTERVAL_MINUTES = 15

# Delay between opening each candidate listing's own detail page, in
# seconds. Only price-passing, not-sold listings get a detail-page fetch,
# so this is normally a handful of pages per check, not the whole page of
# results - keep a small delay anyway so it stays polite.
DETAIL_FETCH_DELAY_SECONDS = 1.5

# ---- Email notifications (free, via Gmail) ----
# 1. Use or create a Gmail account.
# 2. Turn on 2-Step Verification: https://myaccount.google.com/security
# 3. Create an App Password: https://myaccount.google.com/apppasswords
#    (pick "Mail" as the app) and copy the 16-character code it shows you.
#    Do NOT use your normal Gmail password here - it will not work.
GMAIL_ADDRESS = "jengaleviosa@gmail.com"
GMAIL_APP_PASSWORD = "ratv saoj wdzs pajo"  # the 16-character App Password

# Who gets the alert emails. Usually just your own address.
NOTIFY_EMAILS = [
    "jengaleviosa@gmail.com",
]
