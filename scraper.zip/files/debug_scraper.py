"""
Diagnostic only - not part of the real scraper.

Loads the same search page car_scraper.py uses, prints price/sold checks
for the first 15 listings, and - for the first few that pass those checks -
opens the listing's own page and prints the safety and location
classification too, so you can see exactly why something did or didn't
match before waiting for a real run.

Run with:
    python debug_scraper.py
    python debug_scraper.py --save-html    also saves the first opened
                                            listing's raw page source to
                                            debug_listing.html, so you can
                                            check what Kijiji's real markup
                                            looks like and tune the
                                            COORD_PATTERNS regexes in
                                            car_scraper.py if coordinates
                                            aren't being found.
"""

import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

import config
from car_scraper import (
    classify_safety,
    fetch_listing_detail,
    fetch_listings,
    looks_sold,
    parse_price,
    resolve_location,
)

MAX_DETAIL_CHECKS = 5  # how many price-passing candidates to open detail pages for

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()

    for search_url in config.KIJIJI_SEARCH_URLS:
        print(f"--- {search_url} ---")
        listings = fetch_listings(search_url, page)
        print(f"Total listings found on page: {len(listings)}\n")

        detail_checks_done = 0

        for item in listings[:15]:
            price_value = parse_price(item["price"])
            in_budget = price_value is not None and config.MIN_PRICE <= price_value <= config.MAX_PRICE
            sold = looks_sold(item["title"], item["cardText"])

            print(f"TITLE: {item['title']}")
            print(f"  raw price text: {item['price']!r}  ->  parsed: {price_value}  ->  in budget: {in_budget}")
            print(f"  looks sold: {sold}")

            if in_budget and not sold and detail_checks_done < MAX_DETAIL_CHECKS:
                detail_checks_done += 1
                try:
                    detail = fetch_listing_detail(item["link"], page)
                except Exception as exc:
                    print(f"  [warning] couldn't open detail page: {exc}")
                    print()
                    continue

                safety_status = classify_safety(detail["text"])
                loc_status, distance_km, loc_source = resolve_location(detail, item["cardText"])

                print(f"  safety_status: {safety_status}")
                print(f"  location_status: {loc_status}  (source: {loc_source}, distance_km: {distance_km})")

                if detail["coords"] is None:
                    print("  [note] no coordinates found on this ad's page - location fell back to the")
                    print("         place-name lists in config.py. Run with --save-html to inspect the")
                    print("         raw page source and tune COORD_PATTERNS in car_scraper.py if needed.")

                if "--save-html" in sys.argv and detail_checks_done == 1:
                    debug_path = Path(__file__).parent / "debug_listing.html"
                    debug_path.write_text(detail["html"], encoding="utf-8")
                    print(f"  [saved raw page source to {debug_path} for manual inspection]")

            print()

    browser.close()
